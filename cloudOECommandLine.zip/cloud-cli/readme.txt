BlueMix command line

to run: 
  cloud-cli  <command> 
  
   command parameters:
    -target ACEServerURL
    -userID userID
    -pw password
    -config configurationFile
  
  commands:
    login  - log in to ACE
    logout - log out from ACE
    target - set the ACE server url for commands
    
    create-service-offering - create new service offering
    update-service-offering - update a service offering
    update-service-metadata - update ACE's metadata about a service
    delete-service-offering - delete a service offering
    
    templates           - lists all of the registered templates and their metadata URLs
    register-template   - registers or updates a template when already registered
    deregister-template - removes the template from the ACE registry
    
    version - displays the command line version
    help - show command help for a command: help <command>
     
  
  
  configuration file:
     A JSON configuration file may be provided as input.
     The valid fields are "target", userID", and "pw"
